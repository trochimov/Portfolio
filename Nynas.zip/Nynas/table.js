"use strict";

function createTable(rows, colm) {
  this.rows = rows;
  this.colm = colm;
  var table = document.getElementById('trainTable');

    for (i = 1; i <= rows; i++) {
      row = table.insertRow();
      
      for (j = 1; j <= colm; j++) {
      row.insertCell().textContent = 'table cell '+ i + j;      
    }
  }
  document.appendChild(table);
}

function createTable2(rows, colm) {
  this.rows = rows; 
  this.colm = colm; 
  var table = document.getElementById('weatherTable');

    for (i = 1; i <= rows; i++) {
      row = table.insertRow();
      
      for (j = 1; j <= colm; j++) {
      row.insertCell().textContent = 'table cell '+ i + j;      
    }
  }
  document.appendChild(table);
}

function addCityName() {
  document.getElementById("felmeddelende").innerHTML = "Inga problem i trafiken"; 
  
  var input = document.getElementById("cityInput").value;
    document.getElementById("city").innerHTML ="Åker ifrån: " + input;
}

function loadTrainTable() {
  addCityName(); 
  createTable(3,3); 
}

function loadWeatherTable(){
  createTable2(8,4)
}

function createTrainTHead() {
  var table = document.getElementById('trainTable');
  var thead = document.createElement('thead'); 
  
  var tr = document.createElement('tr');
  var th1 = document.createElement('th');
  var th2 = document.createElement('th');
  var th3 = document.createElement('th');
  
  var text1 = document.createTextNode('Nr');
  var text2 = document.createTextNode('Avgår');
  var text3 = document.createTextNode('Ankommer');
  
  th1.appendChild(text1);
  th2.appendChild(text2);
  th3.appendChild(text3);
  tr.appendChild(th1);
  tr.appendChild(th2);
  tr.appendChild(th3);
  thead.appendChild(tr);
  table.appendChild(thead); 

}
function createWeatherTHead() {
  var table = document.getElementById('weatherTable');
  var thead = document.createElement('thead'); 
  
  var tr = document.createElement('tr');
  var th1 = document.createElement('th');
  var th2 = document.createElement('th');
  var th3 = document.createElement('th');
  var th4 = document.createElement('th');
  
  var text1 = document.createTextNode('Klocka');
  var text2 = document.createTextNode('Väder');
  var text3 = document.createTextNode('Värme');
  var text4 = document.createTextNode('Vind');
  
  th1.appendChild(text1);
  th2.appendChild(text2);
  th3.appendChild(text3);
  th4.appendChild(text4);
  tr.appendChild(th1);
  tr.appendChild(th2);
  tr.appendChild(th3);
  tr.appendChild(th4);
  thead.appendChild(tr);
  table.appendChild(thead); 

}